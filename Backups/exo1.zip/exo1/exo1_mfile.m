clc,close all,clear all;

% variables

sat_up = 0.5;
Te = 0.1;

% time vector
tt = (0:Te:10)';

% create values vector
values = zeros(size(tt));
t_start = 1; % sec
n_start = t_start/Te;
values(n_start+1:end) = ones(1,size(tt,1)-n_start)*sat_up;

% pass to simulink stuct
simin.time = tt;
simin.signals.values = values;

% call the simulation
out_step = sim('exo1.slx');

% plot data
plot(out_step.simout.Time,out_step.simout.Data);
title("step response of G(s)");
xlabel("time [sec]")
ylabel("y(t)")



%% do the same for the impulse response
values_impulse = zeros(size(tt));
values_impulse(1) = sat_up;

simin.signals.values = values_impulse;

out_impulse = sim('exo1.slx');

figure
plot(out_impulse.simout.Time,out_impulse.simout.Data);
title("impulse response of G(s)");

xlabel("time [sec]")
ylabel("y(t)")


%% is Te enough ?
G = tf([-1 2],[1 1.85 4]);
poles = pole(G);
natural_frequency = abs(poles)/(2*pi) % [Hz]


